from pyspark import SparkConf, SparkContext
import sys
from pyspark.sql import SparkSession, functions, types

spark = SparkSession.builder.appName('BeforeAfterOpeningofnewrestaurants').getOrCreate()
assert spark.version >= '2.4' # make sure we have Spark 2.4+
spark.sparkContext.setLogLevel('WARN')
sc = spark.sparkContext

#Here we have analyse that how reviews of restaurants were affected after opening of new data
#Assumptions-
#->The first review given to a restaurant is its opening date

def main(keyspace):
    #Get data from cassandra
    cluster_seeds = ['199.60.17.32', '199.60.17.65']
    spark = SparkSession.builder.appName('Spark Cassandra example').config('spark.cassandra.connection.host', ','.join(cluster_seeds)).getOrCreate()
    businessDf = spark.read.format("org.apache.spark.sql.cassandra").options(table='business', keyspace=keyspace).load()
    businessDf=businessDf.cache()
    reviewDf = spark.read.format("org.apache.spark.sql.cassandra").options(table='review', keyspace=keyspace).load()
    
    #Filter top n cities having maximum number of restaurants and collect it as there is only 1 entry
    cityList = businessDf.groupBy('city').count().sort('count',ascending=False).limit(1).select(businessDf['city']).collect()   
    cities = [str(row.city) for row in cityList]
    
    #Filtering data to keep only businesses in the above filtered cities
    businessDf = businessDf.filter(businessDf['city'].isin(cities))  
    
    #Filtering restaurants having pizza and burger category 
    restaurantDf = businessDf.filter(businessDf['categories'].rlike('\W*((?i)pizza|burger(?-i))\W*'))   
    functions.broadcast(restaurantDf)
    
    #Join business and review data
    joinedDf = reviewDf.join(restaurantDf,reviewDf.business_id==restaurantDf.business_id).drop(restaurantDf['business_id']).drop(restaurantDf['stars']).cache()
    
    #Here it is assumed that first review given to a restaurant is its opening date. Group by 'business_id' and find minimum data and name it 'openingDate' for particular restaurant and sort the data according to 'openingDate'
    openDateDf = joinedDf.groupBy('business_id').agg(functions.min('date').alias('openingDate')).sort('openingDate',ascending=False)    
    
    #counting total number of restaurants 
    uniqueBusiness=openDateDf.count()    
    
    #counting recently opened 20% restaurants
    newBusinessCount = int(uniqueBusiness*(0.2))   
    
    #adding opening date to our business&review data
    data = joinedDf.join(openDateDf,joinedDf.business_id==openDateDf.business_id).drop(joinedDf['business_id'])     
    
    #dataframe containing recently opened 20% restaurants
    newBusinessDf=openDateDf.limit(newBusinessCount)      
    
    #adding an index column
    newBusinessDf=newBusinessDf.withColumn('rowIndex',functions.monotonically_increasing_id())     
   
    #take first and last opening date from recently opened restaurants
    firstLast = newBusinessDf.where((newBusinessDf['rowIndex']==0) | (newBusinessDf['rowIndex']==newBusinessCount-1)).select('openingDate').collect()  
    
    #used collect and converted to list as there will be 2 entries i.e. opening date of first restaurant and opening date of last restaurant in top 20% newly opened reataurants
    firstLastList = [str(row.openingDate) for row in firstLast]
    
    #getting old restaurants' data 
    existingRestaurantDf = data.filter(data['openingDate']<firstLastList[1]).sort('date',ascending=False)  
    
    #Filtering data existing restaurants before opening date of first restaurant and opening date of last restaurant in newly opened 20% restaurants
    beforeDf = existingRestaurantDf.filter(existingRestaurantDf['date']<firstLastList[1]).sort('openingDate',ascending=False)
    afterDf = existingRestaurantDf.filter(existingRestaurantDf['date']>firstLastList[0]).sort('openingDate',ascending=True)
    
    #Gropu by business name to get average star rating of restaunrants before and after opening of newly openend data
    beforeReviewDf = beforeDf.groupBy('name').agg(functions.avg('stars').cast(types.IntegerType()).alias('averageBeforeReview'))
    afterReviewDf = afterDf.groupBy('name').agg(functions.avg('stars').cast(types.IntegerType()).alias('averageAfterReview'))
    
    #Joining filtered data with original data to get final result
    finalDf=beforeReviewDf.join(afterReviewDf,beforeReviewDf.name==afterReviewDf.name).drop(beforeReviewDf['name'])
    
    #Saving the result in JSON file
    finalDf.coalesce(1).write.json("beforeAfter",mode='overwrite')
    
    
    
    

if __name__ == '__main__':
    keyspace=sys.argv[1] #keyspace needed to fetch cassandra table
    main(keyspace)

    
