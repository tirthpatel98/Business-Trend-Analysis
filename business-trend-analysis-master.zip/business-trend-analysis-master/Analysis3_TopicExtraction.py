#!/usr/bin/env python
# coding: utf-8

import pandas as pd
import os, json, pyspark, sys, re, string
import numpy as np
assert sys.version_info >= (3, 5)
from pyspark.sql import SparkSession, functions, types
from pyspark import SparkConf, SparkContext
from pyspark.ml.feature import *
from pyspark import Row
from pyspark.sql.functions import udf, log
from pyspark.sql.types import *
from nltk.stem.porter import *
from pyspark.ml.clustering import LDA
from pyspark.ml import Pipeline
from pyspark.ml.feature import StopWordsRemover
from pyspark.ml.feature import Tokenizer, CountVectorizer
spark = SparkSession.builder.appName('example code').getOrCreate()
assert spark.version >= '2.4' # make sure we have Spark 2.4+
spark.sparkContext.setLogLevel('WARN')
sc = spark.sparkContext

#review dataframe
df1 = sqlContext.read.json('review.json')
#business dataframe
df2 = sqlContext.read.json('business.json')
#combining dataframes based on business ID
combined_df = reviewDf.join(businessDf,(df1.business_id==businessDf.business_id)).drop(businessDf.business_id)
#filtering combined dataframe for categories Pizza and Burger
pb=combined_df.filter(combined_df['categories'].rlike('\W*((?i)pizza|burger(?-i))\W*'))
pb.registerTempTable('pb')
pbdf = sqlContext.sql('select business_id, text from pb')
pbrdd = pbdf.rdd
#regular expressions to remove non-alphanumeric characters and words that are shorter than three letters
pattern1 = re.compile('\W+|\W+$|[^\w\s]+|_')
pattern2 = re.compile(r'\W*\b\w{1,2}\b')
rdd = pbrdd.mapValues(lambda x: pattern1.sub(' ', x))     .mapValues(lambda x: pattern2.sub(' ', x))
df = rdd.toDF(schema=['file', 'text'])
#indexing with unique index id
row_with_index = Row(*["id"] + df.columns)
def make_row(columns):
    def _make_row(row, uid):
        row_dict = row.asDict()
        return row_with_index(*[uid] + [row_dict.get(c) for c in columns])
    return _make_row
f = make_row(df.columns)
indexed = (df.rdd.zipWithUniqueId().map(lambda x: f(*x)).toDF(StructType([StructField("id", LongType(), False)] + df.schema.fields)))
#tockenizing, stopword removing and stemming
tokenizer = Tokenizer(inputCol="text", outputCol="tokens")
tokenized = tokenizer.transform(indexed)
stopwordList = ['','get','got','also','really',
 'me',
 'my',
 'myself',
 'we',
 'our',
 'ours',
 'ourselves',
 'you',
 'your',
 'yours',
 'yourself',
 'yourselves',
 'he',
 'him',
 'his',
 'himself',
 'she',
 'her',
 'hers',
 'herself',
 'it',
 'its',
 'itself',
 'they',
 'them',
 'their',
 'theirs',
 'themselves',
 'what',
 'which',
 'who',
 'whom',
 'this',
 'that',
 'these',
 'those',
 'am',
 'is',
 'are',
 'was',
 'were',
 'be',
 'been',
 'being',
 'have',
 'has',
 'had',
 'having',
 'do',
 'does',
 'did',
 'doing',
 'a',
 'an',
 'the',
 'and',
 'but',
 'if',
 'or',
 'because',
 'as',
 'until',
 'while',
 'of',
 'at',
 'by',
 'for',
 'with',
 'about',
 'against',
 'between',
 'into',
 'through',
 'during',
 'before',
 'after',
 'above',
 'below',
 'to',
 'from',
 'up',
 'down',
 'in',
 'out',
 'on',
 'off',
 'over',
 'under',
 'again',
 'further',
 'then',
 'once',
 'here',
 'there',
 'when',
 'where',
 'why',
 'how',
 'all',
 'any',
 'both',
 'each',
 'few',
 'more',
 'most',
 'other',
 'some',
 'such',
 'no',
 'nor',
 'not',
 'only',
 'own',
 'same',
 'so',
 'than',
 'too',
 'very',
 's',
 't',
 'can',
 'will',
 'just',
 'don',
 'should',
 'now',
 'd',
 'll',
 'm',
 'o',
 're',
 've',
 'y',
 'ain',
 'aren',
 'couldn',
 'didn',
 'doesn',
 'hadn',
 'hasn',
 'haven',
 'isn',
 'ma',
 'mightn',
 'mustn',
 'needn',
 'shan',
 'shouldn',
 'wasn',
 'weren',
 'won',
 'wouldn']
remover=StopWordsRemover(inputCol="tokens", outputCol="words" ,stopWords=stopwordList)
cleaned = remover.transform(tokenized)
stemmer = PorterStemmer()
def stem(in_vec):
    out_vec = []
    for t in in_vec:
        t_stem = stemmer.stem(t)
        if len(t_stem) > 2:
            out_vec.append(t_stem)       
    return out_vec
stemmer_udf = udf(lambda x: stem(x), ArrayType(StringType()))
vector_stemmed_df = (cleaned.withColumn("vector_stemmed", stemmer_udf("words")))
cv = CountVectorizer(inputCol="vector_stemmed", outputCol="features")
count_vectorizer_model = cv.fit(vector_stemmed_df)
result = count_vectorizer_model.transform(vector_stemmed_df)
result = result.select("id","features")
#training LDA model
lda = LDA(featuresCol='features', k=5, seed=12, maxIter=50)
model = lda.fit(result)
#extracting topics
topics = model.describeTopics(10).rdd.map(lambda x: list(x)).collect()
vocabulary = count_vectorizer_model.vocabulary
#storing extracted topics into a file
f1out = open("t/topics","w+")
for topic in range(len(topics)):
        towrite = "topic {} : \n".format(topic)
        f1out.write(towrite)
        words = topics[topic][1]
        scores = topics[topic][2]
        stri = ''
        for word in range(len(words)):
            stri += vocabulary[words[word]]+"->"+str(scores[word])+"\n"
        f1out.write(stri[:-3]+"\n")
f1out.close()




