#!/usr/bin/env python
# coding: utf-8
from pyspark import SparkContext, SparkConf 
from pyspark import SQLContext
from pyspark.mllib.linalg import Vectors
import json
from pyspark.sql.functions import *
from pyspark.sql.types import *
import nltk
import nltk.data
from textblob import TextBlob, Word, Blobber
from textblob.classifiers import NaiveBayesClassifier
from textblob.taggers import NLTKTagger
from pyspark.ml.regression import LinearRegression
from pyspark.ml.feature import (VectorAssembler,VectorIndexer,OneHotEncoder,StringIndexer)
import pandas as pd

sc=SparkContext()
sqlContext=SQLContext(sc)
#review dataframe
df1 = sqlContext.read.json('review.json')
#business dataframe
df2 = sqlContext.read.json('business.json')
#combining dataframes based on business ID
cuisine = df1.join(df2,(df1.business_id==df2.business_id)).drop(df2.business_id).drop(df1.stars)
cuisine.registerTempTable("cuisine")
cuisine_sample = sqlContext.sql("select business_id,text,stars from cuisine")
cuisine_sample.registerTempTable("cuisine_sample")
cuisine_text=cuisine_sample.select('business_id','text')

#sentiment analysis process begins. Sentiment analysis was performed for each topic and at a restaurant level. As final output for each restaurant, a polarity was assigned, based on all sentences in the reviews containing the aspects mined in the TopicModeling file.
#words containg service aspect
words = [x.lower() for x in ['sophist','social','servic','order','experi','classi','respect','pour','forget']]
def intersect(row):
    # convert each word in lowercase
    row = [x.lower() for x in row.split()]
    return True if set(row).intersection(set(words)) else False
#aggregate the reviews for each topic for each individual restaurant in order to understand the sentiment for a specific location
sent_detector = nltk.data.load('tokenizers/punkt/english.pickle')
summarised=cuisine_text.rdd.map(lambda business_text:(business_text[0],sent_detector.tokenize(business_text[1].strip()))).map(lambda business_text1:(business_text1[0]," ".join([sent for sent in business_text1[1] if intersect(sent)]))).reduceByKey(lambda x,y:x+y).toDF().withColumnRenamed('_1','BusinessId').withColumnRenamed('_2','Review')
#calculate the average polarity for each topic at each individual restaurant using TextBlob library's sentiment property, which provides the polarity of each input sentence
cuisine_sample_rdd=summarised.rdd
cuisine_sample_polarity = cuisine_sample_rdd.map(lambda x:(x[0],TextBlob(x[1]).sentiment.polarity))
cuisine_pol1=cuisine_sample_polarity.toDF().withColumnRenamed('_1','business_id').withColumnRenamed('_2','pol1')
#words containg food aspect
words = [x.lower() for x in ['burger','pizza','burrito','bourbon','crust','wine','craft','milkshak','melt']]
def intersect(row):
    # convert each word in lowercase
    row = [x.lower() for x in row.split()]
    return True if set(row).intersection(set(words)) else False
#aggregate the reviews for each topic for each individual restaurant in order to understand the sentiment for a specific location
sent_detector = nltk.data.load('tokenizers/punkt/english.pickle')
summarised=cuisine_text.rdd.map(lambda business_text:(business_text[0],sent_detector.tokenize(business_text[1].strip()))).map(lambda business_text1:(business_text1[0]," ".join([sent for sent in business_text1[1] if intersect(sent)]))).reduceByKey(lambda x,y:x+y).toDF().withColumnRenamed('_1','BusinessId').withColumnRenamed('_2','Review')
#calculate the average polarity for each topic at each individual restaurant using TextBlob library's sentiment property, which provides the polarity of each input sentence
cuisine_sample_rdd=summarised.rdd
cuisine_sample_polarity = cuisine_sample_rdd.map(lambda x:(x[0],TextBlob(x[1]).sentiment.polarity))
cuisine_pol2=cuisine_sample_polarity.toDF().withColumnRenamed('_1','business_id').withColumnRenamed('_2','pol2')
cuisine_rating = sqlContext.sql("select distinct business_id,stars from cuisine_sample")
temp = cuisine_rating.join(cuisine_pol1,(cuisine_rating.business_id==cuisine_pol1.business_id),'left').drop(cuisine_rating.business_id)
cuisine_final=temp.join(cuisine_pol2,(temp.business_id==cuisine_pol2.business_id),'outer').drop(cuisine_pol2.business_id)
#adding learned polarity column of service topic
cuisine_final=cuisine_final.withColumn('pol1',when(isnull(cuisine_final.pol1), 0).otherwise(cuisine_final.pol1))
#adding learned polarity column of food topic
cuisine_final=cuisine_final.withColumn('pol2',when(isnull(cuisine_final.pol2), 0).otherwise(cuisine_final.pol2))
cuisine_final=cuisine_final.filter(cuisine_final.business_id.isNotNull())
cuisine_final.registerTempTable("cuisine_final1")
cuisine_final1=sqlContext.sql("select * from cuisine_final1 where not pol1 ==0 and not pol2==0")
training = cuisine_final1

#linear regression begins. Linear regression model takes the vectorized DataFrame as input. Model gives beta coefficients for each feature to determine which topic carries greater weight in contributing to the overall star review
#creating list containing polarities 
numericCols = ['pol1','pol2']
#building a vector assembler that takes the numeric columns as input and outputs these features in vector format to a new column
assembler = VectorAssembler(inputCols=numericCols, outputCol="features")
lr = LinearRegression(maxIter=10, featuresCol="features",labelCol="stars")
training2=assembler.transform(training)
# Fit the model
lrModel = lr.fit(training2)
co = lrModel.coefficients
#creating pandas dataframe to store beta coefficients
dataset = pd.DataFrame({'Column1': [co[0]], 'Column2': [co[1]]})
d = pd.DataFrame({'Category': ('Food','Service'), 'Score': [co[0],co[1]]})
#storing coefficients into json file to give them as input to PowerBI for visualization purpose
Export = d.to_json(r'result.json')






