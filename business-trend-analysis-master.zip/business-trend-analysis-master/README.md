Business Trend Analysis

For any business, there are certain parameters that determines its success or failure. In Business Trend Analysis we have analyzed the effect of some of these parameters on a business. Effect of features like location, competitors, user’s review and density of crowd are taken into consideration in this project. The insights drawn from this analysis produces use cases for both the business as well as users. Analysis were done by processing the data into required form and then querying it to answer the questions. Also one of analysis uses NLP and Regression modeling to extract the information. The obtained analysis are visualized using graphs and pie-charts to give a clear understanding. The dataset used here is Yelp dataset.

URL: https://businesstrendanalysis.000webhostapp.com/index.html

