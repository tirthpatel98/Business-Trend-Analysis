from pyspark import SparkConf, SparkContext
import sys
from pyspark.sql import SparkSession, functions, types

spark = SparkSession.builder.appName('usefulreviewofTrendsetter').getOrCreate()
spark.sparkContext.setLogLevel('WARN')
assert sys.version_info >= (3, 5) 

#Here we analyse how much the reviews given by trendsetter is useful
#Assumptions-
#-> Trensetters are those who have maximum fans


def main(keyspace):
    #Get data from cassandra
    cluster_seeds = ['199.60.17.32', '199.60.17.65']
    spark = SparkSession.builder.appName('Spark Cassandra example').config('spark.cassandra.connection.host', ','.join(cluster_seeds)).getOrCreate()
    businessDf = spark.read.format("org.apache.spark.sql.cassandra").options(table='business', keyspace=keyspace).load()
    reviewDf = spark.read.format("org.apache.spark.sql.cassandra").options(table='review', keyspace=keyspace).load()
    userDf = spark.read.format("org.apache.spark.sql.cassandra").options(table='user', keyspace=keyspace).load()
    
    #Filter trendsetter having maximum number of fans
    userDf=userDf.orderBy('fans',ascending=False).limit(5).drop(userDf['useful'])
    
    #Join user and review data
    joinedDf=reviewDf.join(userDf,reviewDf.user_id==userDf.user_id).drop(userDf['user_id']).cache()

    #Group by user name and find average usefulness of the user's review
    joinedDf=joinedDf.groupby('name').agg(functions.avg('useful').cast(types.IntegerType()).alias('averageUsefulReviews'),functions.count('user_id').alias('countofReviews'))

    #Save final result in json file
    joinedDf.coalesce(1).write.json("usefulReview",mode='overwrite')
    
    
if __name__ == '__main__':
    keyspace=sys.argv[1] #keyspace needed to fetch cassandra table
    main(keyspace)
