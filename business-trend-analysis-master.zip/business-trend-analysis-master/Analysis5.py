from pyspark import SparkConf, SparkContext
import sys
from pyspark.sql import SparkSession, functions, types


spark = SparkSession.builder.appName('crowdAnalysis').getOrCreate()
spark.sparkContext.setLogLevel('WARN')
assert sys.version_info >= (3, 5) 

#Here we analyse the crowd that restaurants encountered on each week day

# Assumptions - 
# -> Here we have assumed that user has visited the restaurant the same day he has given review

def main(inputs):
    #Get data from cassandra
    cluster_seeds = ['199.60.17.32', '199.60.17.65']
    spark = SparkSession.builder.appName('Spark Cassandra example').config('spark.cassandra.connection.host', ','.join(cluster_seeds)).getOrCreate()
    businessDf = spark.read.format("org.apache.spark.sql.cassandra").options(table='business', keyspace=inputs).load()
    reviewDf = spark.read.format("org.apache.spark.sql.cassandra").options(table='review', keyspace=inputs).load()
    
    #Filter top 5 cities having maximum number of restaurants and collect it as there are only 5 entries
    cityList = businessDf.groupBy('city').count().sort('count',ascending=False).limit(5).select(businessDf['city']).collect()
    cities = [str(row.city) for row in cityList]
    
    #Filtering data to keep only businesses in the above filtered cities
    businessDf = businessDf.filter(businessDf['city'].isin(cities))
    restaurantDf = businessDf.filter(businessDf['categories'].rlike('\W*((?i)pizza|burger(?-i))\W*'))
    functions.broadcast(restaurantDf)
    
    #Join business and review data
    joinedDf = reviewDf.join(restaurantDf,reviewDf.business_id==restaurantDf.business_id).drop(restaurantDf['business_id']).drop(restaurantDf['stars']).cache()
    
    #Get day of each date and join it to the data
    dayDf=joinedDf.select('business_id',functions.dayofweek('date').alias("day"))
    joinedDf=joinedDf.join(dayDf,reviewDf.business_id==dayDf.business_id).drop(joinedDf['business_id'])
    
    ##Filtering data to keep only 3 top businesses out of total businesses and collect it as there are only few businesses 
    topbusiness=joinedDf.groupBy('business_id').count().sort('count',ascending=False).limit(3).select(joinedDf['business_id']).collect()
    topbusinessList = [str(row.business_id) for row in topbusiness]

    #For each restaurant group by business name and day to get count of crowd for each week day and save result in json file
    for i in range(len(topbusinessList)):
        topBusinesses = joinedDf.filter(joinedDf['business_id'].isin(topbusinessList)).cahce()
        topBusinesses=topBusinesses.filter(topBusinesses['business_id']==topbusinessList[i])
        topBusinesses=topBusinesses.groupby('name','day').count()
        topBusinesses.coalesce(1).write.json("crowdAnalysis"+str(i),mode='overwrite')
    
    

if __name__ == '__main__':
    inputs=sys.argv[1] #keyspace needed to fetch cassandra table
    main(inputs)
