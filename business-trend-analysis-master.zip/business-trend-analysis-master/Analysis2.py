from pyspark import SparkConf, SparkContext
import sys
from pyspark.sql import SparkSession, functions, types
import json

spark = SparkSession.builder.appName('Friends Group').getOrCreate()
assert spark.version >= '2.4' # make sure we have Spark 2.4+
spark.sparkContext.setLogLevel('WARN')
sc = spark.sparkContext

#Here we analyse that how likely a user and his friends like a particular restaurant. 


def fun(restaurant,userDf,topBusinesses):
    #Filter users of given restaurant and collect is used as number of user per restaurant would not be too large
    userList=restaurant.select(restaurant['user_id']).collect()
    user = [str(row.user_id) for row in userList]
    
    #Get business name
    businessName = restaurant.select(restaurant['business_id']).limit(1).collect()[0][0]
    count=0
    
    #Loop to process data for each user
    for i in user:
        #Get particular user
        filteredUser=userDf.filter(userDf['user_id']==i)
        
        #Get friends data of given user        
        friends = filteredUser.select(filteredUser['friends']).collect()
        friends  = [str(row.friends) for row in friends]
        
        #Get name of given user
        filteredUser=filteredUser.select(filteredUser['user_id'],filteredUser['name'])
        
        #Split friendslist by ','
        friendsList=friends[0].split(",")
        #Append given user to friendslist
        friendsList.append(i)
        
        #Get reviews of friends for particular business
        selectedDf = topBusinesses.where((topBusinesses['business_id']==businessName) & (topBusinesses['user_id'].isin(friendsList)))
        selectedDf=selectedDf.drop(selectedDf['name'])
        selectedDf=selectedDf.join(filteredUser,filteredUser.user_id==selectedDf.user_id).drop(filteredUser['user_id'])
        
        #Get average rating of user and his friends
        averageRatingDf = selectedDf.groupBy('business_id','user_id','name').agg(functions.avg('stars').alias('AverageGroupRating'))
        if count!=0:
            unionDf = unionDf.union(averageRatingDf)
        else:
            unionDf=averageRatingDf
        count+=1
        
    
    #Save final data in json file
    unionDf.coalesce(1).write.json("groupOutput1",mode='overwrite')
        
    
def main(keyspace):
    #Get data from cassandra
    cluster_seeds = ['199.60.17.32', '199.60.17.65']
    spark = SparkSession.builder.appName('Spark Cassandra example').config('spark.cassandra.connection.host', ','.join(cluster_seeds)).getOrCreate()
    businessDf = spark.read.format("org.apache.spark.sql.cassandra").options(table='business', keyspace=keyspace).load()
    reviewDf = spark.read.format("org.apache.spark.sql.cassandra").options(table='review', keyspace=keyspace).load()
    user = spark.read.format("org.apache.spark.sql.cassandra").options(table='user', keyspace=keyspace).load()
    user=user.cache()
    #reviewDf = reviewDf.limit(150000)
    #user=user.limit(150000)
    
    #scalable data to set number of cities, businesses and users per businesses to analyse the data
    numOfCities = 5
    numOfBusiness = 5
    numOfUserPerBusiness = 10
    
    #Filter top 5 cities having maximum number of restaurants and collect it as there are only 5 entries
    cityList = businessDf.groupBy('city').count().sort('count',ascending=False).limit(numOfCities).select(businessDf['city']).collect()
    cities = [str(row.city) for row in cityList]

    #Filtering data to keep only businesses in the above filtered cities
    businessDf = businessDf.filter(businessDf['city'].isin(cities))

    #filtering restaurants/businesses having pizza and burger category 
    restaurantDf = businessDf.filter(businessDf['categories'].rlike('\W*((?i)pizza|burger(?-i))\W*'))
    functions.broadcast(restaurantDf)
    
    #Join business and review data
    joinedDf = reviewDf.join(restaurantDf,reviewDf.business_id==restaurantDf.business_id).drop(restaurantDf['business_id']).drop(restaurantDf['stars']).cache()
    
    #Filtering data to keep only given number of top businesses out of total businesses and collect it as there are only few businesses 
    topbusiness=joinedDf.groupBy('business_id').count().sort('count',ascending=False).limit(numOfBusiness).select(joinedDf['business_id']).collect()
    topbusinessList = [str(row.business_id) for row in topbusiness]
    
    #Filter data of above filtered top data
    topBusinesses = joinedDf.filter(joinedDf['business_id'].isin(topbusinessList)).cache()
    
    #Analyse data for each businesses
    for i in range(numOfBusiness):
        restaurant=joinedDf.filter(joinedDf['business_id']==topbusinessList[i]).limit(numOfUserPerBusiness)
        print(fun(restaurant,user,topBusinesses))
   

if __name__ == '__main__':
    keyspace=sys.argv[1] #keyspace needed to fetch cassandra table
    main(keyspace)

    
